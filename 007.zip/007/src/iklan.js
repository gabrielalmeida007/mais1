const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 35 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *MERCADO PAGO, BOLETO,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/21997123716*
║
╚═〘  DARK BOT 〙
`
}
exports.iklan = iklan